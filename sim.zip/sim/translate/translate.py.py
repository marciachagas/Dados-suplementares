#Reads the .gff3 file and bild a dict whose keys are gene-ID and value is the gene name
#Reads the file with normalized data from RNA-seq for each gene-ID (normalizades data is are in the last column)
#Reads the file with the list of genes (boolean rules file?)
# Writes a table with gene-ID, gene_name, normalized data, for all genes in the boolean model.

# Example of usage: python3 translate.py NZ_CP021380-2.gff3 C1_align_NZ_CP021380-2_sorted.counts.txt CCBH-2022.csv 

# file genes_in_model.txt, containind the list of regulators in the grn, should be in the same directory.

#Script generates two files:
#Table with IDs, gene_name/locus_tag, expression_data: translate_table.csv
#List of genes with normalized data but no entry of gene_name and/or old_locus_tag associated in gff3 file: translate_NO_old_locus_tag.csv file

import sys
import csv
import re

def main():
    #error handling
    if len(sys.argv) != 4:
        sys.exit("Use this script parsing the .gff3 file, the .txt file with the normilized data from RNA-Seq, and the list of genes in the booolean model")
    
    #get dicts with ids (keys) and gene_names (values), and ids(keys) locus (values) in .gff3 file for genes in gff3 file
    id_names, id_locus = id_name_locus(sys.argv[1])

    #read normalized data
    norm_data = id_data(sys.argv[2])

    #get lists with nene names and locus tag
    g_names, g_locus = read_grn(sys.argv[3])
    #print()
    
    #for g in g_raw:

    #DEBUG
    print("#################################################################")   
    print("# of gene names (regulators with no inconsistency): ", len(g_names))
    #print("# of gene fields: ", len(g_raw))
    m_genes = genes_in_model()
    print("# of genes in model: ", len(m_genes))

    


    for g in g_names:
        if g in m_genes:
            m_genes.remove(g)
    print("# of gene IDs in gff3 file = ", len(id_names.keys()))
    print("# of gene IDs in norm_data file = ", len(norm_data.keys()))
    print()
    print("#################################################################")
    print("# Genes with an inconsistency in grn and/or gff3 and/or expression files", m_genes)   
    print("#################################################################")
    print()

    
    
    missing_genes=[]
    i = 0
    with open("translate_table.csv", "w") as f:
        print("#################################################################")
        print("# Table with IDs, gene_name/locus_tag, expression_data: translate_table.csv")
        print("#################################################################")
        print("ID", "\t", "gene_name/locus_tag", "\t", "normalization", file = f)
        for id in norm_data.keys():

            if id in id_names.keys():
                if id_names[id] in g_names:
                    print( id, id_names[id], norm_data[id], file = f)
                    i += 1
                elif id_locus[id] in g_locus:
                    print(id, id_locus[id], norm_data[id], file = f)
                    i += 1
            else:
                missing_genes.append(id)

            #else:
            #   no_id_genes.remove(id_names[id])

    print("# N. of lines in file translate_table.csv = ", i)

    with open("translate_NO_old_locus_tag.csv", "w") as f:
        print("#################################################################")
        print("# Genes with normalized data but no entry of gene_name and/or old_locus_tag associated in gff3 file: translate_NO_old_locus_tag.csv file")
        print("#################################################################")
        for g in missing_genes:
            print(g, file = f)


#read normalized data file
def id_data(file_name):
    data={}
    with open(file_name) as f:
        reader = csv.DictReader(f, delimiter='\t')
        for row in reader:
            #print(row)
            #print(row['featureID'] , "     ", row['tpm'])
            data[row['featureID']] = row['tpm']
    return(data)
            
#Reads .gff3 file identifying IDs and respective gene names
def id_name_locus(file_name):
    names={}

    with open(file_name) as f:
        names = {}
        locus = {}
        lines = f.readlines()
        for line in lines:
            m = re.match(".+RefSeq\s+gene.+\s*ID=([\w-]+)\;Name=(\w+)\;.+old_locus_tag=(\w+)", line)
            if m:
                #print("match ",m.group(1), "    ", m.group(2), "    ",m.group(3 ))
                names[m.group(1)] = m.group(2)
                locus[m.group(1)] = m.group(3)
                #print(names[m.group(1)], locus[m.group(1)]  )
    return(names, locus)



#get regulators in the GRN file
def read_grn(file_name):
    
    with open(file_name, "r") as f_name:
        reader = csv.DictReader(f_name, delimiter = ';')
        names = []
        locus = []
        #raw = []
        '''
        for row in reader:
            try:
                n , l = row['Regulatory gene'].split()
                l = re.sub("\(", "", l)
                l = re.sub("\)", "", l)
                if n not in names:
                    names.append(n)
                if l not in locus:
                    locus.append(l)
 
            except ValueError:
                next
                
           
        '''
        '''
        for row in reader:
            if row['Regulatory gene'] == "ihf":
                next
            else:
                n , l = row['Regulatory gene'].split()
                l = re.sub("\(", "", l)
                l = re.sub("\)", "", l)
                if n not in names:
                    names.append(n)
                if l not in locus:
                    locus.append(l)
                #if row['Regulatory gene'].split() not in raw:
                #    raw.append(row['Regulatory gene'].split())
        '''        
        for row in reader:
            #if row['Regulatory gene'] not in raw:
            #    raw.append(row['Regulatory gene'].strip())
            
            m = re.match("(\w+)\s+\((.+)\)", row['Regulatory gene'].strip())
            if m:
                if m.group(1) not in names and m.group(2) not in locus:
                    names.append(m.group(1))
                    locus.append(m.group(2))
            #else:
            #    print("#####", row['Regulatory gene'])
        
    return(names, locus)

def genes_in_model():
    file_name = "genes_in_model.txt"
    m_genes=[]
    with open(file_name) as f:
        lines = f.readlines()
        for line in lines:
            m_genes.append(line.strip())
    return(m_genes)

main()



